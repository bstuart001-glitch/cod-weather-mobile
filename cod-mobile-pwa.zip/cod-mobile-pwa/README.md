# COD Models Mobile PWA

A lightweight mobile-first launcher/viewer for College of DuPage NEXLAB forecast models.

## What it does
- Opens COD forecast model pages from a clean phone interface
- Lets you save COD "Share Page" URLs as favorites
- Can be installed to an iPhone home screen as a Progressive Web App
- Does not scrape, bulk download, or rehost COD imagery

## How to use on iPhone
1. Host this folder somewhere HTTPS-based, such as Netlify Drop, GitHub Pages, Cloudflare Pages, or your own web host.
2. Open the hosted URL in Safari on your iPhone.
3. Tap Share → Add to Home Screen.
4. Open the new COD Models icon.

## How to add favorites
1. Open the COD forecast model site.
2. Choose the model/sector/product you want.
3. Use COD's Share Page feature to copy the URL.
4. Paste that URL into the Favorites section of this PWA.

## Note
Some websites block iframe embedding. If COD does, use the built-in "Open full site" button. The favorites and mobile launcher still work.

Credit: College of DuPage NEXLAB. Follow COD's terms of use.
